export const environmment = {
    production: false,
    log: true,
    version:'v1'
 }