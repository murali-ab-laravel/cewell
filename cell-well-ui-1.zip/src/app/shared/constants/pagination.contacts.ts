export const PAGE_LENGTH = 100;
export const ITEMS_PER_PAGE = 25;
export const CURRENT_PAGE = 1;
export const PAGE_SIZE_OPTIONS = [2,10,25,50,100];

export const GET_ALL = 10000;


export const ALERT_DUREATIONS = 5;